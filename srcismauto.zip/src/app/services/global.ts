export var GLOBAL = {
    // url: "http://192.168.20.98:8000",
    // url: "https://nnovuproback.ism.edu.ec",
    // url: "http://192.168.31.67:8001",
    url: "http://195.120.50.134:8001",
    // url: "http://localhost:8000",
    // url:  "http://127.0.0.1:8000",
    // url: "http://192.168.254.138:8000",
    // url: "https://34e7-2800-bf0-2a3-7e-b954-f3fe-7d24-2983.ngrok-free.app",
    authorization: "7zXnBjF5PBl7EzG/WhATQw=="
}